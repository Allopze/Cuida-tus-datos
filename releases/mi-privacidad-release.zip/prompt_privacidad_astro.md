# Prompt completo: Experiencia web sobre privacidad y protección de datos con Astro

Quiero crear una experiencia web interactiva usando **Astro**, cuyo objetivo principal sea concientizar a la población sobre el **derecho a la privacidad** y el **derecho a la protección de los datos personales**.

La página debe combinar información seria, útil y verificable con una experiencia irónica e incómoda que simule cómo muchas interfaces digitales manipulan el consentimiento de los usuarios.

## Concepto general

Se debe crear una web con **el mismo contenido**, pero con **3 estilos visuales distintos**:

1. **Brutalismo**
2. **Glassmorphism**
3. **Corporativismo tech**

Cuando el usuario ingrese al sitio, se le debe mostrar aleatoriamente una de estas tres versiones visuales.

Cada vez que recargue la página, el estilo debe volver a elegirse al azar.

No quiero que existan tres páginas completamente duplicadas.

El contenido debe mantenerse centralizado y reutilizarse, cambiando solo el tema visual mediante estilos, clases, layouts, variables CSS o un atributo como `data-theme`.

## Objetivo de la experiencia

La web debe hacer que el usuario reflexione sobre:

- Qué significa aceptar cookies o términos sin leer.
- Cómo algunas interfaces dificultan el rechazo del consentimiento.
- Qué son los patrones oscuros.
- Qué datos personales entregamos en internet.
- Qué derechos tiene una persona respecto a su privacidad y sus datos.
- Cómo protegerse mejor en entornos digitales.

La experiencia debe tener un tono mixto:

- Educativo
- Crítico
- Irónico
- Divertido
- Ligeramente incómodo
- Visualmente memorable

## Flujo de usuario

### 1. Entrada al sitio

Al ingresar al sitio, el usuario debe ver inmediatamente un **modal tipo banner de cookies**, ubicado en el centro de la pantalla.

El modal debe:

- Bloquear parcialmente la experiencia.
- Oscurecer u opacar el contenido detrás.
- Parecer un aviso de cookies común.
- Tener un texto aparentemente normal.
- Mostrar dos botones principales:
  - `Aceptar`
  - `Rechazar`

Ejemplo de texto del modal:

> Usamos cookies para mejorar tu experiencia, personalizar contenido, analizar el tráfico y posiblemente entender demasiado sobre ti. Puedes aceptar o rechazar el uso de cookies.

### 2. Comportamiento del botón “Rechazar”

Cuando el usuario intente mover el cursor sobre el botón `Rechazar`, el botón debe desplazarse a otra posición dentro del modal o cerca de él.

Este comportamiento debe simular una interfaz manipuladora o un patrón oscuro.

Condiciones importantes:

- El botón no debe ser imposible de presionar eternamente.
- Puede moverse algunas veces antes de permitir el clic.
- La experiencia debe ser frustrante, pero no romper la accesibilidad.
- El usuario debe poder interactuar con teclado.
- Debe existir una forma razonable de salir del modal.
- No se debe revelar todavía que todo esto es una crítica o una simulación.

Si el usuario consigue hacer clic en `Rechazar`, debe aparecer otro modal con un mensaje irónico, por ejemplo:

> Lo sentimos, no podemos procesar esta solicitud ahora mismo.

O una variante similar:

> Tu solicitud de privacidad no pudo completarse. Inténtalo de nuevo cuando sea conveniente para nosotros.

Este mensaje debe mantener el tono irónico, pero todavía no debe explicar el propósito de la experiencia.

### 3. Comportamiento del botón “Aceptar”

Si el usuario hace clic en `Aceptar`, el modal desaparece y el usuario puede acceder al contenido principal de la página.

No se debe revelar en ese momento que las cookies son ficticias ni que la experiencia es una simulación.

La sorpresa debe mantenerse hasta el final de la página.

## Contenido principal de la web

La página debe contener información útil, clara y contrastable sobre privacidad y protección de datos personales.

El contenido debe estar escrito en español, con tono cercano y comprensible para público general.

La estructura sugerida es la siguiente:

---

## Hero section

Título llamativo relacionado con privacidad digital.

Ejemplos:

- `Tu privacidad no debería depender de un botón imposible de presionar`
- `Aceptar no siempre significa consentir`
- `Tus datos dicen más de ti de lo que imaginas`

Subtítulo:

> Cada clic, permiso y formulario puede revelar información sobre quién eres, qué haces y qué decisiones tomas. Esta página te ayuda a entender cómo proteger tus datos personales en internet.

CTA principal:

- `Aprender a proteger mis datos`
- `Ver mis derechos`
- `Reconocer patrones oscuros`

---

## Sección 1: ¿Qué son los datos personales?

Explicar de forma sencilla que los datos personales son cualquier información que permite identificar directa o indirectamente a una persona.

Incluir ejemplos como:

- Nombre
- Correo electrónico
- Número de teléfono
- Dirección
- RUT, DNI u otro identificador
- Dirección IP
- Ubicación
- Fotografías
- Datos biométricos
- Historial de navegación
- Preferencias de consumo
- Información de salud
- Datos financieros
- Actividad en redes sociales

La sección debe dejar claro que no solo los datos “obvios” son personales.

También lo pueden ser los patrones de comportamiento.

---

## Sección 2: ¿Por qué importa la privacidad?

Explicar que la privacidad no es “tener algo que esconder”, sino tener control sobre la información personal.

Ideas clave:

- La privacidad protege la autonomía.
- Permite decidir qué compartir y con quién.
- Evita abusos, discriminación, vigilancia indebida y manipulación.
- Reduce riesgos de fraude, suplantación de identidad y exposición.
- Ayuda a mantener límites entre vida personal, laboral y pública.

---

## Sección 3: Derechos sobre tus datos personales

Incluir una explicación simple de los derechos que suelen existir en materia de protección de datos.

Adaptar el contenido al contexto legal correspondiente, especialmente si se usa Chile como referencia.

Explicar derechos como:

- Derecho a saber qué datos se recopilan.
- Derecho a acceder a los datos personales.
- Derecho a corregir datos incorrectos.
- Derecho a solicitar eliminación o cancelación cuando corresponda.
- Derecho a oponerse a ciertos usos.
- Derecho a retirar el consentimiento.
- Derecho a que los datos sean usados solo para fines informados y legítimos.

No escribir esta sección como asesoría legal definitiva.

Debe tener un tono educativo y sugerir revisar fuentes oficiales.

---

## Sección 4: Patrones oscuros

Explicar qué son los patrones oscuros:

> Son decisiones de diseño que empujan, confunden o manipulan al usuario para que tome una acción que quizá no habría elegido libremente.

Incluir ejemplos:

- Botones de aceptar más visibles que los de rechazar.
- Opciones de rechazo escondidas.
- Mensajes diseñados para generar culpa.
- Procesos largos para cancelar una suscripción.
- Casillas premarcadas.
- Interfaces que dificultan retirar consentimiento.
- Lenguaje ambiguo o confuso.
- Urgencia artificial.
- Colores que guían al usuario hacia una opción específica.

Importante:

Esta sección debe educar sobre patrones oscuros, pero sin revelar de forma explícita que el modal inicial fue uno de ellos.

La revelación debe ocurrir después de los términos y condiciones finales.

---

## Sección 5: Cómo proteger tus datos personales

Crear una sección práctica con recomendaciones accionables.

Incluir consejos como:

- Usa contraseñas únicas y seguras.
- Utiliza un gestor de contraseñas.
- Activa la autenticación en dos pasos.
- Revisa permisos de aplicaciones.
- No entregues más datos de los necesarios.
- Lee antes de aceptar.
- Desconfía de formularios invasivos.
- Borra cuentas que ya no uses.
- Revisa la configuración de privacidad en redes sociales.
- Evita conectarte a redes Wi-Fi públicas sin protección.
- Mantén tus dispositivos y aplicaciones actualizados.
- Verifica enlaces antes de hacer clic.
- Revisa periódicamente qué servicios tienen acceso a tus cuentas.

Presentar estos consejos de forma visual, mediante cards, listas interactivas o bloques destacados.

---

## Sección 6: Mini checklist

Agregar una checklist breve titulada:

> Antes de aceptar, pregúntate:

Preguntas sugeridas:

- ¿Qué datos estoy entregando?
- ¿Para qué los usarán?
- ¿Puedo rechazar sin perder acceso injustificadamente?
- ¿Puedo retirar mi consentimiento después?
- ¿La política de privacidad es clara?
- ¿Estoy aceptando por decisión propia o porque la interfaz me empuja?

---

## Sección 7: Términos y condiciones absurdos

Esta sección debe aparecer al final de la página.

Debe parecer inicialmente una sección legal aburrida, titulada algo como:

> Términos y condiciones de uso

Al principio, el texto debe sonar relativamente formal, pero poco a poco debe volverse absurdo, ridículo y divertido.

El objetivo es que el usuario descubra que aceptó algo que probablemente no leyó.

Ejemplos de cláusulas falsas y humorísticas:

- Al aceptar estos términos, declaras haber leído absolutamente todo, aunque ambos sabemos que no lo hiciste.
- Autorizas a esta página a nombrar a tu mascota como Encargada Honoraria de Protección de Datos.
- Aceptas que tus pestañas abiertas puedan ser evaluadas por un comité de señores con traje.
- Reconoces que el botón “Aceptar” fue presionado con plena conciencia, o al menos con ganas de cerrar el modal rápido.
- Nos concedes permiso ficticio para almacenar tus excusas más frecuentes en una carpeta llamada `cosas_que_nadie_lee`.
- Aceptas que, en caso de disputa, esta será resuelta mediante piedra, papel o tijera digital.
- Reconoces que leer términos y condiciones puede prevenir sorpresas desagradables, como esta.
- Aceptas que esta página no es dueña de tu casa, tu perro, tu alma ni tu historial de memes, pero otras plataformas podrían pedir permisos mucho menos graciosos.

El humor debe ser absurdo, pero relacionado con privacidad, consentimiento, datos o comportamiento digital.

Evitar humor excesivamente ofensivo, violento o demasiado desconectado del tema.

---

## Sección 8: Revelación final

Después de los términos y condiciones, mostrar una sección de cierre que revele el propósito de la experiencia.

Título sugerido:

> ¿Leíste antes de aceptar?

Texto sugerido:

> Si aceptaste el aviso inicial sin leer demasiado, no estás solo. Muchas interfaces están diseñadas para que aceptar sea rápido, cómodo y visualmente evidente, mientras que rechazar puede ser más difícil, confuso o incómodo.

Luego explicar:

> El modal inicial, el botón que se movía y el mensaje de error al rechazar fueron una simulación de patrones oscuros. Esta página no busca recolectar tus datos, sino mostrar cómo el diseño puede afectar tus decisiones.

Añadir una frase de cierre:

> La privacidad no debería depender de tu paciencia, tu suerte o tu habilidad para perseguir un botón.

CTA final:

- `Revisar mis hábitos digitales`
- `Compartir esta página`
- `Volver a experimentar otro estilo visual`

---

## Requisitos visuales

Crear tres estilos diferenciados.

### Tema 1: Brutalismo

Características:

- Alto contraste.
- Bordes gruesos.
- Tipografías grandes y fuertes.
- Colores planos e intensos.
- Sombras duras.
- Elementos deliberadamente crudos.
- Botones grandes.
- Sensación de cartel político, protesta o manifiesto digital.

Debe sentirse directo, incómodo y confrontacional.

### Tema 2: Glassmorphism

Características:

- Fondos con degradados suaves.
- Tarjetas translúcidas.
- Efecto blur.
- Bordes sutiles.
- Luces suaves.
- Sensación moderna, etérea y digital.
- Mucho espacio visual.
- Interfaz elegante, pero ligeramente inquietante.

Debe sentirse atractivo y seductor, como muchas plataformas que suavizan visualmente decisiones importantes.

### Tema 3: Corporativismo tech

Características:

- Aspecto de startup tecnológica o SaaS.
- Diseño limpio y profesional.
- Paleta sobria.
- Cards ordenadas.
- Botones pulidos.
- Iconografía simple.
- Lenguaje visual confiable.
- Sensación de empresa tecnológica seria.

Debe transmitir una falsa sensación de confianza institucional.

---

## Requisitos técnicos

Usar **Astro** como framework principal.

La implementación debe considerar:

- Componentes reutilizables.
- Contenido centralizado.
- Sistema de temas.
- Selección aleatoria del tema en cada carga.
- Diseño responsive.
- Accesibilidad básica.
- Buen rendimiento.
- HTML semántico.
- CSS organizado mediante variables, clases o archivos por tema.
- JavaScript solo cuando sea necesario para la interacción del modal y el tema aleatorio.

Estructura sugerida:

```txt
src/
  components/
    CookieModal.astro
    Hero.astro
    Section.astro
    TipCard.astro
    TermsAndConditions.astro
    FinalReveal.astro
  content/
    privacy-content.ts
  layouts/
    BaseLayout.astro
  pages/
    index.astro
  styles/
    global.css
    themes/
      brutalism.css
      glassmorphism.css
      corporate-tech.css
  scripts/
    random-theme.ts
    cookie-modal.ts
```

## Restricción de tamaño de archivos del proyecto

Ningún archivo del proyecto Astro debe superar las **100 líneas de código**.

Esta restricción aplica a:

- Componentes `.astro`
- Archivos `.css`
- Archivos `.ts`
- Archivos `.js`
- Archivos de contenido
- Layouts
- Utilidades
- Cualquier otro archivo fuente creado para el proyecto

Si un archivo se acerca a las 100 líneas, debe dividirse en componentes, módulos, utilidades, archivos de datos o archivos de estilos más pequeños.

La prioridad es que el proyecto sea modular, legible, mantenible y fácil de revisar.

Esta restricción **no aplica a este prompt en Markdown**.

## Lógica del tema aleatorio

Al cargar la página:

1. Crear un array con los tres temas.
2. Seleccionar uno al azar.
3. Aplicarlo al elemento `html` o `body` mediante un atributo como:

```html
<html data-theme="brutalism">
```

Ejemplo de lógica:

```js
const themes = ["brutalism", "glassmorphism", "corporate-tech"];
const selectedTheme = themes[Math.floor(Math.random() * themes.length)];
document.documentElement.dataset.theme = selectedTheme;
```

Cada recarga debe poder mostrar un tema distinto.

No guardar obligatoriamente el tema en `localStorage`, porque la idea es que cambie al recargar.

## Lógica del modal

El modal debe tener estados:

- `visible`
- `accepted`
- `rejected`
- `errorAfterReject`

Comportamiento:

- Al cargar, mostrar modal.
- Si el usuario hace clic en `Aceptar`, cerrar modal.
- Si el usuario intenta pasar sobre `Rechazar`, mover el botón.
- Después de algunos intentos, permitir que el botón pueda ser presionado.
- Si presiona `Rechazar`, mostrar modal de error.
- El modal de error debe tener una opción para continuar, pero sin revelar aún el mensaje educativo final.

Importante:

- No usar cookies reales para esta experiencia.
- No recolectar datos reales.
- No hacer tracking.
- No enviar información a servidores externos.
- Todo debe funcionar de forma local en el navegador.

## Accesibilidad

La experiencia puede ser incómoda, pero no debe ser inaccesible.

Requisitos:

- El modal debe poder cerrarse o manejarse con teclado.
- Los botones deben tener foco visible.
- No bloquear completamente a usuarios que navegan con teclado.
- El botón que se mueve no debe impedir permanentemente la interacción.
- Usar roles y atributos ARIA adecuados cuando corresponda.
- Mantener contraste suficiente en los tres temas.
- Respetar `prefers-reduced-motion` para reducir animaciones.

## Tono de escritura

El tono debe ser:

- Claro
- Inteligente
- Irónico
- Educativo
- Cercano
- Crítico, pero no moralista

Evitar sonar como documento legal pesado en toda la página, excepto en la sección de términos y condiciones, donde el tono legal debe usarse como recurso humorístico.

## Cosas que NO debe hacer la página

- No debe recolectar datos reales.
- No debe instalar cookies reales.
- No debe engañar al usuario fuera de la simulación visual.
- No debe pedir información personal.
- No debe usar servicios externos de tracking.
- No debe revelar el punch demasiado pronto.
- No debe explicar el modal inicial hasta después de los términos y condiciones.
- No debe duplicar tres veces el contenido.
- No debe convertir la experiencia en una broma sin aprendizaje.

## Resultado esperado

Crear una web en Astro que funcione como una experiencia crítica sobre privacidad digital.

La página debe provocar primero una reacción emocional:

- Frustración
- Risa
- Sorpresa
- Incomodidad

Y después convertir esa reacción en reflexión:

- ¿Qué acepté?
- ¿Por qué acepté?
- ¿Leí lo que estaba aceptando?
- ¿La interfaz me dejó decidir libremente?
- ¿Qué puedo hacer distinto la próxima vez?

El resultado final debe sentirse como una mezcla entre:

- Campaña educativa
- Experimento interactivo
- Crítica de UX
- Sitio informativo sobre derechos digitales
- Pieza creativa con humor negro ligero

La frase conceptual de cierre debe ser:

> No aceptes por costumbre. Acepta solo cuando entiendas qué estás entregando.
