# Auditoría de la página sobre protección de datos personales

## A. Diagnóstico general

La página tiene una base pedagógica sólida y el mensaje se entiende con rapidez. La estructura cubre los puntos esenciales: qué son los datos personales, por qué importa protegerlos, cuáles son los derechos de las personas, qué son los patrones oscuros, cómo protegerse y cómo pensar antes de aceptar. Eso cumple bien el objetivo académico.

El principal límite no está en el contenido base, sino en la forma de presentarlo. La experiencia se siente correcta y ordenada, pero todavía no alcanza una identidad visual o narrativa especialmente memorable. Le falta más tensión emocional, más ejemplos cotidianos y una puesta en escena más distintiva para aumentar su impacto.

## Pasada 1

- ~~Reescribí el hero para hacerlo más concreto y accionable.~~
- ~~Reforcé la definición de datos personales con rastros digitales y ejemplos cotidianos.~~
- ~~Hice más claros y útiles los beneficios de la privacidad.~~
- ~~Suavicé la referencia legal vaga del bloque de derechos.~~
- ~~Ajusté consejos y checklist para que suenen menos genéricos.~~
- ~~Preparé una base de fuentes para respaldar las afirmaciones del documento.~~

### Falta de esta pasada

- ~~Validar el build del proyecto después de los cambios de texto.~~
- ~~Decidir si conviene precisar la ley con un país concreto en una segunda pasada.~~
- Si se busca mayor impacto visual, hacer una pasada de diseño más ambiciosa.

## B. Puntuaciones del 1 al 10

- Claridad del mensaje: 8/10
- Calidad del contenido: 8/10
- Poder de concientización: 7/10
- Diseño visual: 6/10
- Espectacularidad: 6/10
- Experiencia de usuario: 7/10
- Profesionalismo general: 7/10

## C. Fortalezas principales

- El tema central se entiende desde el inicio.
- El contenido cubre casi todo lo importante: definición, importancia, derechos, riesgos, consejos y autoevaluación.
- La sección de patrones oscuros está bien elegida porque vuelve visible una práctica que normalmente pasa desapercibida.
- El checklist final ayuda a pasar de la teoría a la acción.
- El bloque de “Términos y condiciones” y el cierre reflexivo convierten la web en una experiencia más activa que un texto informativo simple.

## D. Debilidades principales


- La referencia legal es demasiado vaga. Decir “según la legislación como la ley en Chile u otras normativas” baja el rigor.
- Hay mucha estructura en lista y tarjeta, lo que ordena pero también vuelve la experiencia predecible.
- Falta más vida cotidiana: ejemplos reales de redes sociales, permisos, formularios, compras y apps.
- El tono humorístico de algunos bloques puede restar gravedad si no se equilibra con ejemplos o datos más serios.
- No se ven estadísticas, casos breves, comparaciones visuales ni una narrativa que construya tensión y resolución.

## E. Mejoras concretas

- Agrega un dato fuerte al inicio, como una estadística breve o una situación realista.
- Reescribe la introducción para que empiece desde el problema y luego pase a la definición.
- Sustituye parte de las listas por microhistorias o ejemplos cotidianos.
- Nombra con precisión la normativa aplicable al país objetivo y cita una fuente confiable al final.
- Convierte los derechos en acciones simples: acceso, corrección, eliminación, oposición y retiro del consentimiento.
- Reduce la repetición visual de cajas similares y usa una secuencia más narrativa.
- Refuerza la llamada a la acción final para que el visitante termine con una decisión concreta.
- Mejora la accesibilidad con contraste fuerte, foco visible, jerarquía tipográfica más marcada y lenguaje simple.

## F. Ideas para hacer la página más espectacular

1. Un hero dividido en dos: promesa a la izquierda y visualización del rastro digital a la derecha.
2. Una animación tipo mapa de huella digital que conecte clics, permisos y ubicación.
3. Un simulador de patrones oscuros con dos botones, donde “Rechazar” esté escondido.
4. Una sección “antes y después” que compare una mala y una buena configuración de privacidad.
5. Un contador visual de exposición de datos que cambie según las acciones del usuario.
6. Una línea de tiempo que muestre qué pasa desde que aceptas una política hasta el uso de tus datos.
7. Un panel interactivo de derechos que revele ejemplos al tocar cada derecho.
8. Una infografía tipo semáforo con datos personales sensibles, medios y de bajo riesgo.
9. Una mini historia scrollable sobre una persona que comparte demasiada información.
10. Un cierre con resultado dinámico, tipo perfil de privacidad, que entregue recomendaciones según el checklist.
11. Casos breves y realistas para conectar con la vida diaria del estudiante.
12. Un final más cinematográfico, con una pregunta contundente y una transición visual fuerte hacia el CTA.

## G. Textos mejorados

### Título principal
Tus datos dicen más de ti de lo que imaginas

### Subtítulo
Cada permiso, formulario y ajuste de privacidad revela información que puede usarse para perfilarte, exponerte o influir en tus decisiones. Aprende a reconocerlo y a decidir mejor.

### Llamado a la acción
Quiero aprender a proteger mis datos

### Frase final de concientización
Antes de aceptar, pregúntate si estás eligiendo o solo obedeciendo al diseño.

## H. Veredicto final

Sí, la web cumple bien con el objetivo académico. Explica el tema con una base correcta, cubre los contenidos esenciales y logra introducir una idea importante: que la privacidad también depende del diseño de las interfaces.

Lo que más la haría subir de nivel es mejorar tres cosas: rigor legal, ejemplos cotidianos y una puesta en escena más memorable. Con esos ajustes, puede pasar de ser una buena entrega escolar a una pieza realmente convincente y útil.

## Fuentes de esta auditoría

- [BCN / LeyChile - Ley 19.628 sobre protección de la vida privada](https://www.bcn.cl/leychile/navegar?idNorma=141599): definición de datos personales, consentimiento escrito, revocación, oposición, eliminación, modificación y bloqueo.
- [BCN / LeyChile - Artículo 3, 4 y 6 de la Ley 19.628](https://www.bcn.cl/leychile/navegar?idNorma=141599): oposición a publicidad o encuestas, autorización escrita y medidas sobre datos erróneos o caducos.
- [Privacy Guides - Por qué debería importarme?](https://www.privacyguides.org/es/#por-que-deberia-importarme): privacidad como derecho y por qué importa.
- [EFF - Privacy](https://www.eff.org/issues/privacy): privacidad, vigilancia, autonomía y recolección de datos.
- [MyShadow / Tactical Tech](https://myshadow.org/es): rastros digitales, control de datos y exposición en línea.