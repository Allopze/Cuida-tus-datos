# SEO action plan - Cuida tus datos

Estado: fixes iniciales completados
Fecha de inicio: 2026-05-11

## Contexto inferido

- Tipo de sitio: recurso educativo interactivo.
- Objetivo principal: ensenar privacidad digital, datos personales y patrones oscuros.
- Audiencia principal: estudiantes y publico general en Chile.
- Accion esperada: aprender, completar el checklist y visitar recursos confiables.
- Keyword principal sugerida: datos personales y privacidad digital.
- Keywords secundarias: que son los datos personales, como proteger mis datos personales, privacidad digital, patrones oscuros, derechos sobre datos personales Chile.

## Auditoria base resumida

| Area | Estado inicial | Prioridad |
|---|---|---|
| SEO tecnico | Sin canonical, sitemap ni robots.txt detectables | P1 |
| Metadata | Title y description basicos; sin Open Graph ni Twitter Cards | P1 |
| Contenido | Buen contenido educativo, faltan FAQ, fuentes y senales de autoridad | P2 |
| Conversion | CTA claro, pero sin eventos ni objetivo medible | P2 |
| Performance | HTML estatico; demasiadas fuentes externas y efectos visuales costosos | P2 |
| Accesibilidad | Modal sin semantica de dialogo; checklist con labels no asociados | P1 |
| Medicion | Sin analytics ni eventos | P1 |
| Social | Sin imagen ni metadata social | P1 |

## Cambios realizados

- Creado `SEO-ACTION-PLAN.md` como bitacora y roadmap de implementacion.
- Actualizado `src/layouts/BaseLayout.astro` con:
  - title y description por defecto orientados a "datos personales y privacidad digital";
  - meta robots `index,follow`;
  - canonical condicional mediante `PUBLIC_SITE_URL`;
  - Open Graph y Twitter Cards condicionales;
  - JSON-LD base tipo `WebPage`;
  - reduccion de familias/pesos de Google Fonts.
- Actualizado el H1 en `src/content/privacy-content.ts` para incluir la keyword principal.
- Agregada seccion de FAQ visible en `src/pages/index.astro`.
- Agregado schema `FAQPage` basado en las preguntas visibles.
- Corregida la asociacion `input`/`label` del checklist.
- Actualizados los themes para usar solo las fuentes que ahora se cargan.
- Mejorada la accesibilidad del modal de privacidad:
  - `role="dialog"`, `aria-modal`, `aria-labelledby` y `aria-describedby`;
  - botones con `type="button"`;
  - foco inicial;
  - cierre con Escape;
  - trap basico de foco;
  - restauracion del foco anterior al cerrar.
- Agregado `robots.txt` con rastreo permitido.
- Agregado `public/llms.txt` con resumen para buscadores conversacionales y crawlers de IA.
- Agregado asset social base `public/og-cuida-tus-datos.svg`.
- Agregado soporte CSS para `prefers-reduced-motion`.
- Reducido el costo visual en movil removiendo `background-attachment: fixed` y `backdrop-filter` en tarjetas bajo 768px.
- Agregada fuente oficial de Ley Chile/BCN para la Ley 19.628 en recursos.
- Reforzado el footer con contexto educativo, fecha de actualizacion y disclaimer de no asesoria legal.
- Agregada instrumentacion base en `src/scripts/tracking.ts`:
  - empuja eventos a `window.dataLayer` si existe;
  - emite `CustomEvent('landing:event')`;
  - mide clics con `data-track`;
  - mide cambios de checklist.
- Marcados eventos para CTA hero, modal, checklist, recursos externos y CTA final.
- Agregado `.env.example` con `PUBLIC_SITE_URL` para activar canonical y URLs absolutas de social metadata en despliegue.
- Ejecutado `npm run build` correctamente. El output incluye HTML estatico, `robots.txt`, `llms.txt` y `og-cuida-tus-datos.svg`.
- Reemplazado `public/robots.txt` por endpoint `src/pages/robots.txt.ts`, que agrega `Sitemap:` automaticamente cuando existe `PUBLIC_SITE_URL`.
- Agregado endpoint `src/pages/sitemap.xml.ts`; genera sitemap con la home cuando existe `PUBLIC_SITE_URL` y queda vacio si falta la variable para evitar URLs falsas.
- Extendida `.env.example` con `PUBLIC_GTM_ID` y `PUBLIC_PLAUSIBLE_DOMAIN`.
- Agregado soporte opcional para GTM y Plausible desde `src/layouts/BaseLayout.astro`.
- Los eventos en `src/scripts/tracking.ts` ahora tambien se envian a Plausible si `window.plausible` existe.
- Creado `.env` local, ignorado por Git, con `PUBLIC_SITE_URL=https://cuidatusdatos.lat` y `PUBLIC_PLAUSIBLE_DOMAIN=cuidatusdatos.lat`.
- Verificado build con variables reales del dominio: canonical, `og:url`, `og:image`, Twitter image, `robots.txt` con sitemap y `sitemap.xml` quedan generados.

## Backlog priorizado

### P1

- [x] Mejorar metadata SEO, Open Graph y Twitter Cards.
- [x] Agregar canonical condicionado al dominio final.
- [x] Agregar `robots.txt`.
- [x] Agregar asset social base.
- [x] Corregir accesibilidad del modal de privacidad.
- [x] Asociar labels del checklist con sus inputs.
- [x] Agregar JSON-LD base.

### P2

- [x] Reforzar H1 y title con keyword principal.
- [x] Agregar bloque FAQ visible.
- [x] Agregar senales de autoria, institucion, fecha y fuentes.
- [x] Reducir fuentes externas.
- [x] Agregar soporte para `prefers-reduced-motion`.
- [x] Definir eventos de medicion para CTA, modal, checklist y recursos.

## Requiere validacion en entorno real

- Confirmar que `https://cuidatusdatos.lat` es el dominio final antes de publicar.
- Sustituir `PUBLIC_GTM_ID=GTM-XXXXXXX` por un contenedor real o eliminarlo si se usara solo Plausible.
- HTTPS, cabeceras HTTP y posible `X-Robots-Tag`.
- Lighthouse/PageSpeed/Core Web Vitals reales.
- Vista previa social en LinkedIn, WhatsApp, Slack y X.
- Search Console e indexacion final.

## Siguientes pasos naturales

1. Confirmar el dominio final `https://cuidatusdatos.lat`.
2. Publicar el build y probar `https://cuidatusdatos.lat/robots.txt` y `https://cuidatusdatos.lat/sitemap.xml`.
3. Crear o conectar el proyecto en Plausible para `cuidatusdatos.lat`, o reemplazar por GTM/GA4 real.
4. Mapear los eventos ya instrumentados a conversiones o objetivos.
5. Validar con Lighthouse/PageSpeed en movil y escritorio.
6. Probar la vista previa social con el dominio real.
7. Verificar indexacion en Google Search Console.
8. Si el proyecto crecera, crear rutas de recursos o guias para capturar busquedas long-tail.
