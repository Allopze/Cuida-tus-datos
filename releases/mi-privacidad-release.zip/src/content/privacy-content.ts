export const content = {
  hero: {
    title: "Datos personales y privacidad digital: aprende a proteger lo que compartes",
    subtitle: "Cada clic, permiso y formulario puede revelar quién eres, dónde estás y qué decisiones tomas. Esta página te muestra qué son los datos personales y cómo protegerlos antes de compartirlos.",
    cta: "Aprender a proteger mis datos"
  },
  section1: {
    title: "¿Qué son los datos personales?",
    description: "Los datos personales son cualquier información que permite identificarte directa o indirectamente. No son solo tu nombre o tu correo: también cuentan rastros como tu ubicación, tus hábitos de navegación y tus preferencias.",
    list: ["Nombre", "Correo electrónico", "Número de teléfono", "Dirección", "RUT, DNI u otro identificador", "Dirección IP", "Ubicación", "Fotografías", "Datos biométricos", "Historial de navegación", "Preferencias de consumo", "Información de salud", "Datos financieros", "Actividad en redes sociales"]
  },
  section2: {
    title: "¿Por qué importa la privacidad?",
    description: "La privacidad no significa esconder algo: significa decidir qué compartes, con quién y para qué. Cuando pierdes ese control, otros pueden perfilarte, influirte o exponer información que no querías entregar.",
    list: ["Protege tu autonomía y tu capacidad de decidir.", "Reduce el riesgo de fraude, suplantación y extorsión.", "Evita vigilancia indebida y perfiles comerciales invasivos.", "Te ayuda a separar tu vida personal, académica y pública."]
  },
  section3: {
    title: "Derechos sobre tus datos personales",
    description: "En Chile, la Ley 19.628 regula la protección de la vida privada y exige autorización escrita para el tratamiento de datos, además de permitir revocarla. También contempla la oposición a ciertos usos y la eliminación, modificación o bloqueo de datos cuando corresponda.",
    list: ["Autorizar por escrito el tratamiento de tus datos.", "Revocar tu autorización por escrito.", "Oponerte al uso de tus datos con fines de publicidad, investigación de mercado o encuestas.", "Pedir eliminación o cancelación de datos sin base legal o caducos.", "Pedir modificación de datos erróneos, inexactos, equívocos o incompletos.", "Solicitar bloqueo cuando la exactitud o vigencia sea dudosa."]
  },
  section4: {
    title: "Patrones oscuros",
    description: "Son decisiones de diseño que empujan, confunden o manipulan para que elijas una opción que no habrías tomado con calma. Aparecen en banners de cookies, permisos, suscripciones y cancelaciones.",
    list: ["Botones de aceptar más visibles que los de rechazar.", "Opciones de rechazo escondidas.", "Mensajes diseñados para generar culpa.", "Procesos largos para cancelar una suscripción.", "Casillas premarcadas.", "Interfaces que dificultan retirar consentimiento.", "Lenguaje ambiguo o confuso.", "Urgencia artificial.", "Colores que guían al usuario hacia una opción específica."]
  },
  section5: {
    title: "Cómo proteger tus datos personales",
    list: ["Usa contraseñas únicas y un gestor de contraseñas.", "Activa la autenticación en dos pasos.", "Revisa permisos de apps y extensiones.", "No entregues más datos de los necesarios.", "Lee, al menos en parte, antes de aceptar.", "Desconfía de formularios que piden demasiado.", "Borra cuentas que ya no uses.", "Revisa la privacidad de redes sociales y buscadores.", "Evita Wi-Fi públicas sin protección.", "Mantén tus dispositivos y aplicaciones actualizados.", "Verifica enlaces antes de hacer clic.", "Revisa qué servicios tienen acceso a tus cuentas."]
  },
  checklist: {
    title: "Antes de aceptar, pregúntate:",
    list: ["¿Qué datos estoy entregando?", "¿Para qué los usarán?", "¿Puedo rechazar sin perder acceso injustificadamente?", "¿Puedo retirar mi consentimiento después?", "¿La política de privacidad es clara?", "¿Estoy aceptando por decisión propia o porque la interfaz me empuja?"]
  },
  faq: {
    title: "Preguntas frecuentes sobre privacidad digital",
    list: [
      {
        question: "¿Qué datos personales comparto cuando navego por internet?",
        answer: "Puedes compartir tu dirección IP, ubicación aproximada, historial de navegación, identificadores del dispositivo, preferencias, formularios enviados y datos de cuentas conectadas."
      },
      {
        question: "¿Qué es un patrón oscuro en privacidad?",
        answer: "Es una decisión de diseño que empuja a aceptar, entregar datos o mantener una suscripción usando confusión, presión visual, culpa, fricción o información incompleta."
      },
      {
        question: "¿Cómo puedo proteger mis datos personales en redes sociales?",
        answer: "Revisa la visibilidad de tu perfil, limita permisos de apps conectadas, evita publicar datos sensibles, activa autenticación en dos pasos y elimina cuentas o accesos que ya no uses."
      },
      {
        question: "¿Qué derechos tengo sobre mis datos personales en Chile?",
        answer: "La Ley 19.628 reconoce derechos vinculados al acceso, modificación, eliminación, bloqueo y oposición en ciertos usos de datos. Esta página lo resume con fines educativos, no como asesoría legal."
      },
      {
        question: "¿Debo aceptar todas las cookies para usar una página?",
        answer: "No siempre. Muchas páginas deberían permitir rechazar cookies no esenciales. Si rechazar es difícil, confuso o visualmente escondido, puede haber un patrón oscuro."
      }
    ]
  },
  terms: {
    title: "Términos y Condiciones (que nadie lee)",
    list: [
      "Juras solemnemente que leíste este texto gigante en menos de 3 segundos, demostrando tener superpoderes de lectura veloz.",
      "Nos das permiso absoluto para usar tu historial de búsqueda de Google como guion para una telenovela dramática de bajo presupuesto.",
      "Si tienes un perro o un gato, aceptas que a partir de hoy son propiedad intelectual nuestra (es broma, pero a que asusta).",
      "Autorizas que, en caso de que tu celular se quede pegado, te echemos la culpa a ti y no a la falta de memoria de tu equipo.",
      "Aceptas ceder los derechos de tu alma a cambio de 15 minutos extras de batería cuando estés en 1%.",
      "Te comprometes a dejar de darle a 'Aceptar todo' en cada página que visitas, aunque los dos sabemos que lo vas a volver a hacer mañana.",
      "Nos concedes el derecho exclusivo de enviarte mentalmente un 'te lo dije' cuando alguna app te robe los datos por no leer sus condiciones.",
      "Entiendes que todo esto es una exageración, pero la cantidad de cosas locas y abusivas que aceptas en la vida real sin leer es 100% cierta y preocupante."
    ]
  },
  reveal: {
    title: "¿Leíste antes de aceptar?",
    description1: "Si aceptaste el aviso inicial sin leer demasiado, no estás solo. Muchas interfaces están diseñadas para que aceptar sea rápido, cómodo y visualmente evidente, mientras que rechazar puede ser más difícil, confuso o incómodo.",
    description2: "El modal inicial, el botón que se movía y el mensaje de error al rechazar fueron una simulación de patrones oscuros. Esta página no busca recolectar tus datos, sino mostrar cómo el diseño puede afectar tus decisiones.",
    quote: "La privacidad no debería depender de tu paciencia, tu suerte o tu habilidad para perseguir un botón.",
    resourcesTitle: "Recursos útiles para seguir aprendiendo",
    resources: [
      {
        label: "MyShadow",
        description: "Guías prácticas para proteger tu huella digital y revisar tu exposición en línea.",
        href: "https://myshadow.org/es"
      },
      {
        label: "Electronic Frontier Foundation",
        description: "Defensa de derechos digitales, privacidad y libertad en internet.",
        href: "https://www.eff.org/issues/privacy"
      },
      {
        label: "Privacy Guides",
        description: "Recomendaciones abiertas para mejorar seguridad, privacidad y navegación.",
        href: "https://www.privacyguides.org/es/"
      },
      {
        label: "Agencia Española de Protección de Datos",
        description: "Material de referencia sobre derechos, deberes y buenas prácticas.",
        href: "https://www.aepd.es/"
      },
      {
        label: "Ley Chile - Ley 19.628",
        description: "Texto oficial en la Biblioteca del Congreso Nacional de Chile sobre protección de la vida privada.",
        href: "https://www.bcn.cl/leychile/navegar?idNorma=141599"
      }
    ],
    cta: "Revisar mis hábitos digitales"
  }
};
