const overlay = document.getElementById('cookie-modal-overlay');
const cookieModal = document.getElementById('cookie-modal');
const errorModal = document.getElementById('error-modal');
const btnAccept = document.getElementById('btn-accept');
const btnReject = document.getElementById('btn-reject');
const btnErrorContinue = document.getElementById('btn-error-continue');
const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;

const getFocusableElements = () => {
  if (!overlay) return [];

  return Array.from(
    overlay.querySelectorAll<HTMLElement>('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')
  ).filter(element => !element.hasAttribute('disabled') && !element.classList.contains('hidden'));
};

if (btnReject) {
  // Añadimos una transición suave para la animación infinita
  btnReject.style.transition = 'transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)';

  const moveButton = (e: Event) => {
    e.preventDefault();
    // Se moverá eternamente sin límite de intentos, sumando rotación y escala
    const x = (Math.random() - 0.5) * 300;
    const y = (Math.random() - 0.5) * 150;
    const rot = (Math.random() - 0.5) * 30;
    btnReject.style.transform = `translate(${x}px, ${y}px) rotate(${rot}deg) scale(0.9)`;
  };

  btnReject.addEventListener('mouseover', moveButton);
  btnReject.addEventListener('touchstart', moveButton, { passive: false });

  btnReject.addEventListener('click', () => {
    if (cookieModal && errorModal) {
      cookieModal.classList.add('hidden');
      errorModal.classList.remove('hidden');
      btnErrorContinue?.focus();
    }
  });
}

const closeModal = () => {
  if (overlay) {
    overlay.classList.add('hidden');
    document.body.style.overflow = 'auto';
    previousFocus?.focus();
  }
};

btnAccept?.addEventListener('click', closeModal);
btnErrorContinue?.addEventListener('click', closeModal);

if (overlay) {
  document.body.style.overflow = 'hidden';
  btnAccept?.focus();

  overlay.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      closeModal();
      return;
    }

    if (event.key !== 'Tab') return;

    const focusableElements = getFocusableElements();
    const firstElement = focusableElements[0];
    const lastElement = focusableElements[focusableElements.length - 1];

    if (!firstElement || !lastElement) return;

    if (event.shiftKey && document.activeElement === firstElement) {
      event.preventDefault();
      lastElement.focus();
    }

    if (!event.shiftKey && document.activeElement === lastElement) {
      event.preventDefault();
      firstElement.focus();
    }
  });
}
